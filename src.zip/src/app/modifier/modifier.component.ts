import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EmployeeService } from '../services/employee.service';
import { CoreService } from '../core/core.service';
import { EmpAddEditComponent } from '../emp-add-edit/emp-add-edit.component';


@Component({
  selector: 'app-modifier',
  templateUrl: './modifier.component.html',
  styleUrls: ['./modifier.component.scss']
})
export class ModifierComponent {
  empForm: FormGroup;

  constructor(
    private _fb: FormBuilder,
    private _empService: EmployeeService,
    private _dialogRef: MatDialogRef<ModifierComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _coreService: CoreService
  ) {
    this.empForm = this._fb.group({
      Nom: '',
      Prenom: '',
      email: '',
      Numero: '',
      Adresse: '',
      motdePass: '',
      Date: ''
    });
  }

  ngOnInit(): void {
    this.empForm.patchValue(this.data);
  }

  onFormSubmit() {
    console.log(this.empForm.value)
    
    var user = {
      nom: this.empForm.value.Nom,
      prenom: this.empForm.value.Prenom,
      email: this.empForm.value.email,
      num: this.empForm.value.Numero,
      motDePasse: this.empForm.value.motdePass,
      adresse: this.empForm.value.Adresse,
      date: this.empForm.value.Date,
      statuts:"accepte",
      role:"admin"
    }

    console.log(user)

      this._empService.addEmployee(user).subscribe({
        next: (res) => {
          console.log(user)
          this._coreService.openSnackBar('Ajouter un admin!', 'close');
        },
        error: console.log,
      });

  }

}
