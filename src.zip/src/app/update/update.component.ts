import { Component, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CoreService } from '../core/core.service';
import { ModifierComponent } from '../modifier/modifier.component';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.scss']
})
export class UpdateComponent {

  empForm: FormGroup;

  role: string[] = [
    'admin',
    'responsable',
    'comercieux',
  ];

  constructor(
    private _fb: FormBuilder,
    private _empService: EmployeeService,
    private _dialogRef: MatDialogRef<ModifierComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _coreService: CoreService
  ) {
    this.empForm = this._fb.group({
      Nom:null,
      Prenom: null,
      email: null,
      Numero: null,
      Adresse:null,
      motdePass: null,
      Date: null,
      role:null
    });

    console.log(this.data.id)

  }

  ngOnInit(): void {
    this.empForm.patchValue(this.data);
  }

  onFormSubmit() {
    console.log(this.empForm.value)    
    var user = {
      nom: this.empForm.value.Nom,
      prenom: this.empForm.value.Prenom,
      email: this.empForm.value.email,
      num: this.empForm.value.Numero,
      motDePasse: this.empForm.value.motdePass,
      adresse: this.empForm.value.Adresse,
      date: this.empForm.value.Date,
      statuts:"accepte",
      role:this.empForm.value.role,
    }

      this._empService.updateEmployee(this.data.id,user).subscribe({
        next: (res) => {
          console.log(user)
          this._coreService.openSnackBar('utilisateur modifier !', 'close');
        },
        error: console.log,
      });

  }

}
